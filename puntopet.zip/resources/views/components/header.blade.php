<section class="header-panel">
	<div class="pantalla  d-flex align-items-end p-4">
		<div class="container">
			<h4 class="text-white">{{$titulo}}</h4>
		</div>
	</div>

</section>