<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.header'); ?>
    <?php $__env->slot('titulo' , 'Mis Datos'); ?>
<?php echo $__env->renderComponent(); ?>

<div class="container">
	<div class="row">
		<?php echo $__env->make('includes.nav-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col pt-4 pb-4 mt-4 mb-4">


				<form action="">
					<?php echo csrf_field(); ?>

					<div class="row mb-4">
						<div class="col text-right">
							<button type="submit" class="btn btn-danger">
								Actualizar
							</button>
						</div>
					</div>

					<div class="row mb-4">
						<div class="col-md-4">
							<p>Nombre</p>
						</div>
						<div class="col">
							<h6><?php echo e(title_case(Auth::user()->nombre)); ?> <?php echo e(title_case(Auth::user()->apellido)); ?></h6>
						</div>
					</div>


					<div class="row mb-4">
						<div class="col-md-4">
							<p>Foto de Perfil</p>
						</div>
						<div class="col">
							<input type="file" name="perfil" class="form-control">
						</div>
					</div>

					<div class="row mb-4">
						<div class="col-md-4">
							<p>Cambiar Contraseña</p>
						</div>
						<div class="col">
							<input type="password" name="password" class="form-control">
						</div>
					</div>

					<div class="row mb-4">
						<div class="col-md-4">
							<p>Confirme su Contraseña</p>
						</div>
						<div class="col">
							<input type="password" name="password_confirmation" class="form-control">
						</div>
					</div>

					


				</form>
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/user/datos.blade.php ENDPATH**/ ?>