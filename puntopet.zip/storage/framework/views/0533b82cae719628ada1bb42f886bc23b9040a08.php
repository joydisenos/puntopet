<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.header'); ?>
    <?php $__env->slot('titulo' , 'Mi Cuenta'); ?>
<?php echo $__env->renderComponent(); ?>

<div class="container">
	<div class="row">
		<?php echo $__env->make('includes.nav-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col pt-4 pb-4 mt-4 mb-4">
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/user/pedidos.blade.php ENDPATH**/ ?>