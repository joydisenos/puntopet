<div class="col-md-3 pt-4 pb-4 mt-4 mb-4">

	<div class="text-center">
		<?php if(Auth::user()->foto_perfil == null): ?>
		<img src="<?php echo e(asset('images/perfil.png')); ?>" style="max-width: 100px;" class="img-fluid rounded-circle" alt="">
		<?php else: ?>
		<img src="<?php echo e(asset('storage/archivos/' . Auth::user()->id . '/' . Auth::user()->foto_perfil)); ?>" style="max-width: 100px;" class="img-fluid rounded-circle" alt="">
		<?php endif; ?>
		<h6 class="m-3"><?php echo e(title_case(Auth::user()->nombre)); ?></h6>
	</div>
	<ul class="list-group list-group-flush">

		<?php if(auth()->check() && auth()->user()->hasRole('admin|dev')): ?>
		<a href="<?php echo e(route('admin.usuarios')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('admin.usuarios')) ? 'active' : ''); ?>">
			  	<i class="fa fa-users mr-3" aria-hidden="true"></i> Usuarios
			</li>
		</a>

		<a href="<?php echo e(route('admin.configuraciones')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('admin.configuraciones')) ? 'active' : ''); ?>">
			  	<i class="fa fa-cog mr-3" aria-hidden="true"></i> Configuraciones
			</li>
		</a>
		<?php else: ?>

		<?php if(auth()->check() && auth()->user()->hasRole('negocio|dev')): ?>
		<a href="<?php echo e(route('negocio.productos')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('negocio.productos')) ? 'active' : ''); ?>">
			  	<i class="fa fa-birthday-cake mr-3" aria-hidden="true"></i> Productos
			</li>
		</a>

		<a href="<?php echo e(route('negocio.ventas')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('negocio.ventas')) ? 'active' : ''); ?>">
			  	<i class="fa fa-money mr-3" aria-hidden="true"></i> Ventas
			</li>
		</a>



		<a href="<?php echo e(route('negocio.datos')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('negocio.datos')) ? 'active' : ''); ?>">
			  	<i class="fa fa-info-circle mr-3" aria-hidden="true"></i> Perfil
			</li>
		</a>

		<a href="#">
		  	<li class="list-group-item">
			  	<i class="fa fa-info-circle mr-3" aria-hidden="true"></i> Horario y envíos
			</li>
		</a>
		<?php else: ?>
		<a href="<?php echo e(route('usuario.favoritos')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('usuario.favoritos')) ? 'active' : ''); ?>">
			  	<i class="fa fa-heart mr-3" aria-hidden="true"></i> Favoritos
			</li>
		</a>
		<a href="<?php echo e(route('usuario.direcciones')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('usuario.direcciones')) ? 'active' : ''); ?>">
			  	<i class="fa fa-map-marker mr-3" aria-hidden="true"></i> Direcciones
			</li>
		</a>
		<a href="<?php echo e(route('usuario.datos')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('usuario.datos')) ? 'active' : ''); ?>">
			  	<i class="fa fa-info-circle mr-3" aria-hidden="true"></i> Perfil
			</li>
		</a>
		<a href="<?php echo e(route('usuario.pedidos')); ?>">
		  	<li class="list-group-item <?php echo e((URL::current() == route('usuario.pedidos')) ? 'active' : ''); ?>">
			  	<i class="fa fa-birthday-cake mr-3" aria-hidden="true"></i> Pedidos
			</li>
		</a>
		<?php endif; ?>

		<?php endif; ?>

		<a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
		  	<li class="list-group-item">
			  	Salir
			</li>
		</a>
	</ul>

</div><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/includes/nav-side.blade.php ENDPATH**/ ?>