<section class="header-panel">
	<div class="pantalla  d-flex align-items-end p-4">
		<div class="container">
			<h4 class="text-white"><?php echo e($titulo); ?></h4>
		</div>
	</div>

</section><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/components/header.blade.php ENDPATH**/ ?>