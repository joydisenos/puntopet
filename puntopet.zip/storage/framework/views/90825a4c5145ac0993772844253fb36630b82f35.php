<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.header'); ?>
    <?php $__env->slot('titulo' , 'Productos'); ?>
<?php echo $__env->renderComponent(); ?>

<div class="container">
	<div class="row">
		<?php echo $__env->make('includes.nav-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col pt-4 pb-4 mt-4 mb-4">


				<div class="row">
					<div class="col mb-4 text-right">
						<a href="<?php echo e(route('negocio.crear.producto')); ?>" class="btn btn-danger">
							Nuevo Producto
						</a>
					</div>
				</div>

				<div class="row">
					<div class="col">
						<div class="table-responsive">
							<table class="table">
								<thead>
									<th>Imagen</th>
									<th>Nombre</th>
									<th>Precio</th>
									<th>Ventas</th>
									<th>Estatus</th>
									<th></th>
								</thead>
								<tbody>
									<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<?php if($producto->foto == null): ?>
											<img src="<?php echo e(asset('images/logo-01.png')); ?>" style="max-width: 50px;" alt="Imagen <?php echo e($producto->nombre); ?>">
											<?php else: ?>
											<img src="<?php echo e(asset('storage/archivos/' . Auth::user()->id . '/' . $producto->foto)); ?>" style="max-width: 50px;" alt="Imagen <?php echo e($producto->nombre); ?>">
											<?php endif; ?>
										</td>
										<td><?php echo e(title_case($producto->nombre)); ?></td>
										<td><?php echo e(str_limit($producto->descripcion , 30)); ?></td>
										<td></td>
										<td><?php echo e($producto->estatusProducto($producto->estatus)); ?></td>
										<td>
											<a href="<?php echo e(route('negocio.modificar.producto' , [$producto->id])); ?>">modificar</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			
			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/negocio/productos.blade.php ENDPATH**/ ?>