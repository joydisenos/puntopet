<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.header'); ?>
    <?php $__env->slot('titulo' , $legal->nombre); ?>
<?php echo $__env->renderComponent(); ?>

<div class="container">
	<div class="row">
		<?php echo $__env->make('includes.nosotros-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col pt-4 pb-4 mt-4 mb-4">
			<?php echo $legal->texto; ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntopet\resources\views/legales.blade.php ENDPATH**/ ?>